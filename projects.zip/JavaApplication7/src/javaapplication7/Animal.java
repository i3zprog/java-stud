
package javaapplication7;


public class Animal {
    private String Type ;
    private String size;
    private double weight;
    
    public Animal(){
    }
        
    public Animal(String Type ,String size ,double weight){
        this.Type = Type ;
        this.size = size;
        this.weight = weight;
    
    }

    @Override
    public String toString() {
        return "Animal{" + "Type=" + Type + ", size=" + size + ", weight=" + weight + '}';
    }

 public void move (){
     System.out.println(Type +"  move on ");
          
 }
 
 public void makenoise(){
     System.out.println("speed up");
 }
 
    
    
  
}

