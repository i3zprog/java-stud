
package javaapplication7;


public class Dog extends Animal{
    private String earShape;
    private String tailShape;

    public Dog(String earShape, String tailShape, String Type, String size, double weight) {
        super(Type, size, weight);
        this.earShape = earShape;
        this.tailShape = tailShape;
    }

    

    @Override
    public String toString() {
        return "Dog{" + "earShape=" + earShape + ", tailShape=" + tailShape + '}';
    }

    

   
    
    
    
    
    
}
