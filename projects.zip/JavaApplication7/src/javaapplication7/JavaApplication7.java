
package javaapplication7;


public class JavaApplication7 {

   
    public static void main(String[] args) {
        Animal a = new Animal("fast", "large" , 270 );
        Dog dog = new Dog("short ears", "small tail", "short ears" ,"calm", 20.42);
        
        a.move();
        a.makenoise();
        
        
        System.out.println(dog.toString());
        
        System.out.println(a.toString());
        
        
    }
    
}
