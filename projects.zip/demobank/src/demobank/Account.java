
package demobank;


public class Account {
    private String customername;
    private String customerPhone;
    private String number;
    private double balance;
    
    
    
    public void depos(double dep){
        balance += dep;
        System.out.println("تم ايداع المبلغ"+ dep + "الرصيد الحالي "+ balance);
        
    }

    public Account() {
    }

    public Account(String customername, String customerPhone, String number, double balance) {
        this.customername = customername;
        this.customerPhone = customerPhone;
        this.number = number;
        this.balance = balance;
    }
    
    
    
    
    
    
    public void sahb(double shb){
        if(shb > 0){
            shb -= balance;
            System.out.println("تم سحب " + shb + "الرصيد الحالي "+ balance);
        }else
            System.out.println("no enough money");
    
            
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    
    
}
