package javaapplication4;

import java.util.Scanner;

public class JavaApplication4 {

    public static  Scanner in = new Scanner(System.in);
    public static void main(String[] args) {
    startup();
    in.close();
    }
    public static void startup(){
        int x;
    while(true){
        System.out.println("1------ Elc" + "\n" +
                           "2------ Water" + "\n"+
                           "3------ Tel" + "\n" +
                           "0------ Exit");
        x = in.nextInt();
        if(x==0) break;
        switch(x){
            case 1: Elc();
            break;
            case 2: Wa();
            break;
            case 3: Te();
            break;
            default: System.out.println("ERROR");
        }
                
                
         
           
    }
    }
    
    public static void Elc() {
        double k,t;
        System.out.println("ادخل عدد الكيلو وات :");
        k= in.nextDouble();
        t= k*0.02;
        System.out.println("قيمة فاتورة الكهرب " );
        System.out.println(t);
    }
    
     public static void Wa() {
        double k,t;
        System.out.println("ادخل عدد الليترات :");
        k= in.nextDouble();
        t= k*0.01;
        System.out.println("قيمة فاتورة الماء " );
         System.out.println(t);
    }
     
      public static void Te() {
        double k,t;
        System.out.println("ادخل عدد الجياجابايت :");
        k= in.nextDouble();
        t= k*0.009;
        System.out.println("قيمة فاتورة البيانات ");
          System.out.println(t);
    }
}

