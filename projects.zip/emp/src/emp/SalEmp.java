
package emp;


public class SalEmp extends Employee{
    private double annualSalary;
    private boolean isRetired;

    public SalEmp(double annualSalary, String hireDate, String name, String birthdate) {
        super(hireDate, name, birthdate);
        this.annualSalary = annualSalary;
    }

    @Override
    public double collectPay() {
        double monthly =annualSalary;
        double salary = (isRetired)? monthly*0.6:monthly;
        return salary;
    }
    public void retire(){
        terminate("12/12/2025");
        isRetired = true;
    }
    
    
    
    
}
