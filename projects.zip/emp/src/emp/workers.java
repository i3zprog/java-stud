
package emp;

public class workers {
    private String name;
    private String birthdate;
    protected String enddate;

    public workers() {
       
    }

    public workers(String name, String birthdate) {
        this.name = name;
        this.birthdate = birthdate;
    }
    
    
    
    
    
    public int getAge(){
        int currentYear = 2025 ;
        int birthYear =Integer.parseInt(birthdate.substring(6));
        return (currentYear - birthYear) ;       
                
    }
         
    
   public double collectPay(){
           return 0.0;
       
   }
   
   public void terminate(String enddate){
       this.enddate = enddate;
   }

    
   
   
   
}
