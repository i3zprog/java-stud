
package emp;


public class Employee extends workers{
    private long employeeId;
    private String hireDate;

    public static int employeeNo = 1;
    
    public Employee( String hireDate, String name, String birthdate) {
        super(name, birthdate);
        this.employeeId = employeeNo++;
        this.hireDate = hireDate;
    }
    
    
    
    
    
    @Override
    public String toString() {
        return "Employee{" + "employeeId=" + employeeId + 
               ", hireDate=" + hireDate + '}';
    }
    
    
    
}
