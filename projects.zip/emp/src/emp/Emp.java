
package emp;


public class Emp {

   
    public static void main(String[] args) {
       Employee emp1 = new Employee("10/10/2020","aziz","04/04/2000");
        System.out.println(emp1.getAge());
        
        
        
        SalEmp emp2 = new SalEmp(120000 ,"12/12/2025", "aziz","04/04/2000");
        System.out.println(emp2.collectPay());
        
        
        
       
   
    }
    
}
