﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        pnlForm.Visible = false;
        pnlShow.Visible = true;
        lblName.Text = txtName.Text;
        lblID.Text = txtID.Text;
        lblMobile.Text = txtMobile.Text;
        lblType.Text = rdType.Text;
        lblSpc.Text = drpSpc.Text;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        pnlShow.Visible = false;
        pnlMsg.Visible = true;
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        pnlForm.Visible = true;
        pnlShow.Visible = false;
    }
}