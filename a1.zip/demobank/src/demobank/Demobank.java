
package demobank;


public class Demobank {

   
    public static void main(String[] args) {
        Account aziz = new Account();
        
        Account az1 = new Account("azoz", "testing", "234341343",2000);
        
       aziz.setCustomerPhone("0521234212");
       aziz.setCustomername("abdulaziz");
       aziz.setBalance(2000.2);
       
       
       
       aziz.depos(99);
       
    }
    
}
