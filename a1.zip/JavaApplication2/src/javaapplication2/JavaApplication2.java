
package javaapplication2;

import java.util.Scanner;


public class JavaApplication2 {

    
    public static void main(String[] args) {
       double mark;
       String message = null;
       Scanner in = new Scanner(System.in);
       while(true){
       System.out.println("ادخل الدرجة او -100 للتوقف");
       mark = in.nextDouble();
       if(mark == -100) break;
       if(mark>=0 && mark<= 100){
       if(mark>=95)
               message="A+";
       else if(mark>=90)
               message="A";
       else if(mark>=80)
               message="B";
       else if(mark>=70)
               message="C";
       else if(mark>=60)
               message="D";
       else
               message="F";
       System.out.println("التقدير هو :" + message);
       }else
           System.out.println("الدرجة المدخلة خاطئة");
       }
        
       in.close();
    }
    
}


