
package studclasses;


public class Studclasses {

  
    public static void main(String[] args) {
        
        cars car = new cars();
        
        car.setModel("toyota");
        car.setMake("bmw");
        car.setColor("black");
        car.setDoors(4);
        
        car.DescCars();
    }
    
}
