
package studclasses;

public class cars {
    private String model;
    private String make;
    private String color;
    private int doors;
    private boolean conv;

    public void setMake(String make) {
      if (make == null) this.make = "make not found";
        this.make = make;
        String smallchar = make.toLowerCase();
        switch(smallchar){
            case "toyota" : this.make = make;
            break;
            case "bmw" : this.make = make;
            break;
            case "nissan" : this.make = make;
            break;
            default: this.make = "undeifined";
        }
        
        
        
        
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public int getDoors() {
        return doors;
    }

    public boolean isConv() {
        return conv;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setColor(String color) {
        if (color == null) this.color = "color not found";
        this.color = color;
        String smallchar = color.toLowerCase();
        switch(smallchar){
            case "black" : this.color
            
        }
    }

    public void setDoors(int doors) {
        this.doors = doors;
    }

    public void setConv(boolean conv) {
        this.conv = conv;
    }
    
    
    
    public void DescCars() {
        System.out.println("doors" + doors+"make:"+ 
                            make + "color: " + color + "model: "+
                            model + "model: "+ (conv ? conv: "conv:"));
    }
    
}
