package a1;





public class A1 {

   
    
    
    
    public static void main(String[] args) {
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
