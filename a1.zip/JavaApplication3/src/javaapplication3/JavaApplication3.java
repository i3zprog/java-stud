
package javaapplication3;


public class JavaApplication3 {

    
    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        
        while(x>=0){
            System.out.println(x);
            x--;
        }
        
        
        
        System.out.println("===============================");
        System.out.println("*******************************");
         do{
             System.out.println(y);
             y--;
         } while(y <= 0);
        
        
        System.out.println("===============================");
        System.out.println("*******************************");
       
        
        for(int i=0; i<=50; i+=2)
        System.out.println(i);
    }
    
}
